'use strict';

require('chai').should();

describe('NexT', () => {
  require('./helpers');
  require('./tags');
  require('./validate');
});
